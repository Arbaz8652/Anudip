package org.practicletest.question1;

import java.time.LocalDate;

public record EmployeeDdeatails(int empId, String empName, String joiningDate) {

}
