package org.practicletest.question2;

public class PassWordFormattException extends Exception {

	PassWordFormattException(){
		super();
	}
	PassWordFormattException(String str){
		super(str);
	}
	
}

